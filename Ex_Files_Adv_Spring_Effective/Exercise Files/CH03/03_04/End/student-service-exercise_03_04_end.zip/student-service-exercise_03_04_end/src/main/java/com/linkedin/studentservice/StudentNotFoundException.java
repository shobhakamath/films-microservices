package com.linkedin.studentservice;

public class StudentNotFoundException extends RuntimeException
{
}
